#include <iostream>
#include <fstream>
#include <string>
#include <bits/stdc++.h>
#include <stdlib.h>
#include <cmath>

using namespace std;

int main(){
    cout << "Hi" << endl;
    
    return 0;
}
