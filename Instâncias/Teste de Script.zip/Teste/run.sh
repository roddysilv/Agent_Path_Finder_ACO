#!/bin/sh
g++ -o p1 p1.cpp
g++ -o p2 p2.cpp
./p1
./p2
python3 p3.py
