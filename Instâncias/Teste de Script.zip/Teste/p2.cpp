#include <iostream>
#include <fstream>
#include <string>
#include <bits/stdc++.h>
#include <stdlib.h>
#include <cmath>

using namespace std;

int main(){
    
    cout << "Hello" << endl;
    
    return 0;
}
