print("Piton")
